This file can be opened through the start menu, "Qt Installer Framework Example" section!

