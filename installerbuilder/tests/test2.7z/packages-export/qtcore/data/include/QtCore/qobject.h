#ifndef QOBJECT_H
#define QOBJECT_H

#error "Sorry, this class is just fake..."

class QObject
{
};

#endif
